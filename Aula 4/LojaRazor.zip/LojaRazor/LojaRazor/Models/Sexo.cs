﻿
namespace LojaRazor.Models
{
    public enum Sexo
    {
        Masculino,
        Feminino
    }
}
